import React from "react";

export const Tile = () => {
  return (
    <div className="tile-container">
      
    </div>
  );
};

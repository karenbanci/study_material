// create and export styled components along with the animation and theming
